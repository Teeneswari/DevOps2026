import Attendance from "./Attendance";

function StudentCard({ student, updateAttendance }) {
  const isEligible = student.attendance >= 75;

  return (
    <div
      className={`student-card ${
        !isEligible ? "low-attendance" : ""
      }`}
    >
      <h2>{student.name}</h2>

      <p>
        <strong>Roll Number:</strong> {student.rollNo}
      </p>

      <p>
        <strong>Branch:</strong> {student.branch}
      </p>

      <Attendance
        student={student}
        updateAttendance={updateAttendance}
      />

      <p
        className={
          isEligible ? "eligible" : "not-eligible"
        }
      >
        {isEligible ? "Eligible" : "Not Eligible"}
      </p>
    </div>
  );
}

export default StudentCard;