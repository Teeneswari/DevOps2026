function Attendance({ student, updateAttendance }) {
  return (
    <div className="attendance-section">
      <p>
        Attendance: <strong>{student.attendance}%</strong>
      </p>

      <button
        className="present-btn"
        onClick={() => updateAttendance(student.id, "Present")}
      >
        Present
      </button>

      <button
        className="absent-btn"
        onClick={() => updateAttendance(student.id, "Absent")}
      >
        Absent
      </button>
    </div>
  );
}

export default Attendance;