import StudentCard from "./StudentCard";

function StudentList({ students, updateAttendance }) {
  return (
    <div className="student-list">
      {students.map((student) => (
        <StudentCard
          key={student.id}
          student={student}
          updateAttendance={updateAttendance}
        />
      ))}
    </div>
  );
}

export default StudentList;