import { useState } from "react";

import Header from "./components/Header";
import StudentList from "./components/StudentList";
import Summary from "./components/Summary";

import "./App.css";

function App() {
  const initialStudents = [
    {
      id: 1,
      name: "Varshitha",
      rollNo: "2503A52796",
      branch: "CSE-AI",
      attendance: 82,
      todayStatus: "Present",
    },
    {
      id: 2,
      name: "Rahul",
      rollNo: "2503A52797",
      branch: "CSE",
      attendance: 68,
      todayStatus: "Absent",
    },
    {
      id: 3,
      name: "Sravani",
      rollNo: "2503A52798",
      branch: "CSE-AI",
      attendance: 91,
      todayStatus: "Present",
    },
    {
      id: 4,
      name: "Kiran",
      rollNo: "2503A52799",
      branch: "CSE",
      attendance: 73,
      todayStatus: "Absent",
    },
    {
      id: 5,
      name: "Anjali",
      rollNo: "2503A52800",
      branch: "CSE-AI",
      attendance: 87,
      todayStatus: "Present",
    },
  ];

  const [students, setStudents] = useState(initialStudents);

  const [search, setSearch] = useState("");

  const updateAttendance = (id, status) => {
    setStudents((currentStudents) =>
      currentStudents.map((student) => {
        if (student.id !== id) {
          return student;
        }

        let newAttendance = student.attendance;

        if (status === "Present") {
          newAttendance = Math.min(
            student.attendance + 1,
            100
          );
        } else {
          newAttendance = Math.max(
            student.attendance - 1,
            0
          );
        }

        return {
          ...student,
          attendance: newAttendance,
          todayStatus: status,
        };
      })
    );
  };

  const resetAttendance = () => {
    setStudents(initialStudents);
  };

  const filteredStudents = students.filter(
    (student) =>
      student.name
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      student.rollNo
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      student.branch
        .toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <div className="app">
      <Header />

      <main>
        <Summary students={students} />

        <div className="controls">
          <input
            type="text"
            placeholder="Search students..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button
            className="reset-btn"
            onClick={resetAttendance}
          >
            Reset Attendance
          </button>
        </div>

        <StudentList
          students={filteredStudents}
          updateAttendance={updateAttendance}
        />
      </main>
    </div>
  );
}

export default App;